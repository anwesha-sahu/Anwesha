#include "Bat.h"

using namespace sf;

//definitions of methods in Bat class

//Bat class constructor


//get_Position()


//get_Shape()


//moveRight()


//moveLeft()


//stopRight()


//stopLeft()



//update()
