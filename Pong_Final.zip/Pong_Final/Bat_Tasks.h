#pragma once 	//pragmatic information to the compiler not to read/open 
		//same header files after first time read
#include<SFML/Graphics.hpp>

using namespace sf;

class Bat{
//declare position

//declare shape

//declare speed

//declare bool var for right and left movement


public:
//declare constructor method 

//delare get_position() method  


//declare get_shape()

//declare moveRight()

//declare moveLeft()

//declare stopRight()

//declare stopLeft()

//declare update()


};
