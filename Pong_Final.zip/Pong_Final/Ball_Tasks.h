#pragma once 	//pragmatic information to the compiler not to read/open 
		//same header files after first time read
#include<SFML/Graphics.hpp>

using namespace sf;

class Ball
{
private:
        //Position
	
	//Shape	
	
	//Speed
	
	//X Direction
	
	//Y Direction
	
public:
	//Constructor
	

	//getPosition()
	

	//getShape()
	
	//getXVelocity()
	
	//reboundSides()
	
	//reboundBatOrTop()

	//reboundBottom()

	//update(Time)

};
