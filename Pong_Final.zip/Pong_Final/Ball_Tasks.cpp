#include "Ball.h"

//Definitions of all methods of Ball class are written below

//Constructor

//getPosition()
	
//getShape()
	
//getXVelocity()
	
//reboundSides()
	
//reboundBatOrTop()

//reboundBottom()

//update(Time)
